===============================================================================
VELMORA INSTAGRAM COMPANION — CHROME EXTENSION & SETUP PACKAGE (v1.0.0)
===============================================================================

WHAT IS INSIDE THIS ZIP?
------------------------
  Velmora-Instagram-Companion/
    |-- extension/              <-- SELECT THIS FOLDER IN CHROME "LOAD UNPACKED"
    |     |-- manifest.json
    |     |-- src/
    |           |-- background.js
    |           |-- content-app.js
    |-- SETUP-GUIDE.pdf         <-- Illustrated step-by-step installation guide
    |-- README.txt              <-- Quick instructions & troubleshooting (this file)

-------------------------------------------------------------------------------
QUICK INSTALLATION STEPS (GOOGLE CHROME)
-------------------------------------------------------------------------------

STEP 1: EXTRACT (UNZIP) THIS ARCHIVE FIRST
  - Right-click the downloaded "Velmora-Instagram-Companion-v1.0.0.zip" file.
  - Click "Extract All..." (Windows) or double-click (Mac) to unzip it to a
    permanent folder on your computer (for example: Documents or Desktop).
  - IMPORTANT: Do NOT delete or move the extracted folder after installing,
    because Chrome loads the extension directly from that folder.

STEP 2: OPEN CHROME EXTENSIONS
  - Open Google Chrome.
  - In the top address bar, type:
      chrome://extensions
    and press Enter.

STEP 3: ENABLE DEVELOPER MODE
  - Look at the top-right corner of the chrome://extensions page.
  - Switch the "Developer mode" toggle to ON.

STEP 4: LOAD THE UNPACKED EXTENSION FOLDER
  - Click the "Load unpacked" button in the top-left corner.
  - Open the extracted "Velmora-Instagram-Companion" folder.
  - Click the inner "extension" folder (the folder that contains manifest.json)
    and click "Select Folder".

STEP 5: CONFIRM & PIN THE EXTENSION
  - Confirm that "Velmora Influencer R&D" (Version 1.0.0) appears in your
    extensions list and its blue toggle switch is ON.
  - Click the puzzle-piece (Extensions) icon in the top-right Chrome toolbar
    and click the Pin icon next to "Velmora Influencer R&D".

STEP 6: CONNECT TO VELMORA & START RESEARCH
  - Open the Velmora Management System in Chrome (refresh the tab with F5 if
    it was already open).
  - Go to Marketing -> Influencer R&D.
  - Click "Check Connection" in the top-right corner.
  - Verify that:
      1) "Chrome Extension" shows "Connected" (Version 1.0.0)
      2) "Instagram Session" shows "Session Detected"
         (If it says "Login Required", click "Open Instagram" and log in.)

-------------------------------------------------------------------------------
HOW TO USE THE INSTAGRAM COMPANION WINDOW & GLOBAL MINIPLAYER
-------------------------------------------------------------------------------
  - When you start a research batch, the extension opens a dedicated
    "Instagram Companion Window" to scroll creator Reels automatically.
  - Keep the Instagram Companion window OPEN and UNMINIMIZED while research
    is running.
  - If the Companion window is minimized or completely covered by another
    window, scraping will automatically pause ("Paused — Instagram Companion
    window appears to be covered") so no profiles fail. Simply bring the
    Companion window back to the front to resume automatically.
  - You can switch to any other Velmora department (Sales, Logistics, Finance,
    Inventory, etc.) at any time — the Global MiniPlayer stays visible in the
    bottom-right corner of Velmora so you can monitor, pause, or stop the batch.

-------------------------------------------------------------------------------
TROUBLESHOOTING COMMON ERRORS
-------------------------------------------------------------------------------

1. ERROR: "Manifest file is missing or unreadable"
   CAUSE: You selected the outer "Velmora-Instagram-Companion" folder or tried
          to load from inside the unextracted .zip file.
   FIX:   Extract the .zip file first, open "Velmora-Instagram-Companion", and
          select the inner "extension" folder.

2. PROBLEM: Velmora says Chrome Extension "Not Detected"
   CAUSE: The Velmora tab was opened before the extension was installed, or the
          extension toggle is switched off.
   FIX:   1) Go to chrome://extensions and verify "Velmora Influencer R&D" is ON.
          2) Refresh the Velmora tab (press F5).
          3) Click the "Check Connection" button in Influencer R&D.

3. PROBLEM: Instagram Session shows "Login Required" or "Not Available"
   CAUSE: You are not logged into Instagram in this Chrome profile.
   FIX:   Click "Open Instagram" (or visit https://www.instagram.com), sign in
          to your work Instagram account, return to Velmora, and click
          "Check Connection".

4. PROBLEM: Batch says "Paused — Instagram Companion window appears to be covered"
   CAUSE: Chrome throttles background rendering when the Companion window is
          minimized or completely hidden behind another maximized window.
   FIX:   Click the Instagram Companion window on your taskbar to bring it to
          the front. Research will resume automatically within 2-3 seconds.

===============================================================================
Velmora Management System — Internal Distribution Package (v1.0.0)
===============================================================================
